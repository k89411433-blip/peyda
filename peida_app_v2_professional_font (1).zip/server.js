const express=require("express");
const path=require("path");
const fs=require("fs");
const app=express();
const PORT=process.env.PORT||3000;
const DATA=path.join(__dirname,"data");
fs.mkdirSync(DATA,{recursive:true});
app.use(express.json({limit:"5mb"}));
app.use(express.static(__dirname));
function read(name, fallback=[]){const f=path.join(DATA,name);try{return JSON.parse(fs.readFileSync(f,"utf8"))}catch{return fallback}}
function write(name,data){fs.writeFileSync(path.join(DATA,name),JSON.stringify(data,null,2))}
app.get("/api/health",(req,res)=>res.json({ok:true,app:"Peida",time:new Date().toISOString()}));
app.get("/api/ads",(req,res)=>res.json(read("ads.json",[])));
app.post("/api/ads",(req,res)=>{const a=read("ads.json",[]);const item={id:Date.now(),createdAt:new Date().toISOString(),...req.body};a.unshift(item);write("ads.json",a);res.status(201).json(item)});
app.get("/api/categories",(req,res)=>res.json(read("categories.json",[])));
app.get("/api/messages",(req,res)=>res.json(read("messages.json",[])));
app.post("/api/messages",(req,res)=>{const m=read("messages.json",[]);const item={id:Date.now(),createdAt:new Date().toISOString(),...req.body};m.push(item);write("messages.json",m);res.status(201).json(item)});
app.listen(PORT,()=>console.log(`Peida server: http://localhost:${PORT}`));