# پیدا — نسخه فعال V1

این بسته شامل:
- `index.html` رابط کاربری فعال و RTL
- `server.js` بک‌اند Express با API پایه
- `data/` داده‌های JSON برای شروع
- `p-logo.svg` لوگوی اختصاصی «پ» برای برند پیدا

## اجرای محلی
1. Node.js نصب باشد.
2. در پوشه پروژه اجرا کنید:
   `npm install`
3. سپس:
   `npm start`
4. مرورگر را روی:
   `http://localhost:3000`
   باز کنید.

## API
- GET `/api/health`
- GET `/api/ads`
- POST `/api/ads`
- GET `/api/categories`
- GET `/api/messages`
- POST `/api/messages`

این نسخه برای شروع اتصال واقعی آماده شده است؛ برای نسخه تولیدی باید احراز هویت OTP، دیتابیس PostgreSQL/Supabase، آپلود امن تصاویر، نقشه، نوتیفیکیشن، WebSocket و درگاه پرداخت به سرور متصل شوند.
